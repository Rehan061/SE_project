# Supermarket-management-system using JAVA 

![Main Screen](https://github.com/barak03/Supermarket-management-system/blob/master/images/main%20screen.png)

## About the peoject:
The project uses Java.\
The system can manage employees by adding and editing their details and the same goes for customer management and store inventory management and in addition the system has a screen for the cashier.\
For each product added to the receipt the same quantity is reduced from the inventory.\
The system uses .dat files that do not require additional software installation in order for the system to work.\
in the code there is separation between the view from the "behind-the-scenes" code (like using an API) You can change the logic of the code without changing anything in the view.\
In the code there is also a Junit test file that tests ןnvalid input in the system.


### Log in screen
![Log in screen](https://github.com/barak03/Supermarket-management-system/blob/master/images/Log%20in%20screen.png)

### Managment screen
![Managment screen](https://github.com/barak03/Supermarket-management-system/blob/master/images/Managment%20screen.png)

### Product screen
![Product screen](https://github.com/barak03/Supermarket-management-system/blob/master/images/Product%20screen.png)

### Invoice screen
![ Invoice screen](https://github.com/barak03/Supermarket-management-system/blob/master/images/Invoice%20screen.png)
